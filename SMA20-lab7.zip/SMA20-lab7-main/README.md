# SMA-lab7
SMA 2020 - Laborator 7
